<?php
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET");
header("Access-Control-Allow-Headers: Content-Type");

error_reporting(0);

$koneksi = mysqli_connect("localhost", "root", "", "perguruan_tinggi");

$aksi = $_POST["aksi"] ?? "";

switch ($aksi) {

    case "tampil":
        $sql = "SELECT * FROM alumni ORDER BY nm_alumni";
        $result = mysqli_query($koneksi, $sql);
        $data = [];

        while ($row = mysqli_fetch_assoc($result)) {
            $data[] = $row;
        }

        echo json_encode($data);
        break;

    case "simpan":
        $nim = $_POST["nim"];
        $nm_alumni = $_POST["nm_alumni"];
        $prodi = $_POST["prodi"];
        $tmpt_lahir = $_POST["tmpt_lahir"];
        $tgl_lahir = $_POST["tgl_lahir"];
        $alamat = $_POST["alamat"];
        $no_hp = $_POST["no_hp"];
        $thn_lulus = $_POST["thn_lulus"];
        $foto = $_POST["foto"];

        $sql = "INSERT INTO alumni VALUES 
                ('$nim','$nm_alumni','$prodi','$tmpt_lahir','$tgl_lahir','$alamat','$no_hp','$thn_lulus')";

        if (mysqli_query($koneksi, $sql)) {
            file_put_contents("foto/$nim.jpeg", base64_decode($foto));
            echo json_encode(["status" => "berhasil"]);
        } else {
            echo json_encode(["status" => "gagal"]);
        }
        break;

    case "ubah":
        $nim = $_POST["nim"];
        $nm_alumni = $_POST["nm_alumni"];
        $prodi = $_POST["prodi"];
        $tmpt_lahir = $_POST["tmpt_lahir"];
        $tgl_lahir = $_POST["tgl_lahir"];
        $alamat = $_POST["alamat"];
        $no_hp = $_POST["no_hp"];
        $thn_lulus = $_POST["thn_lulus"];
        $foto = $_POST["foto"];

        $sql = "UPDATE alumni SET
                nm_alumni='$nm_alumni',
                prodi='$prodi',
                tmpt_lahir='$tmpt_lahir',
                tgl_lahir='$tgl_lahir',
                alamat='$alamat',
                no_hp='$no_hp',
                thn_lulus='$thn_lulus'
                WHERE nim='$nim'";

        if (mysqli_query($koneksi, $sql)) {
            file_put_contents("foto/$nim.jpeg", base64_decode($foto));
            echo json_encode(["status" => "berhasil"]);
        } else {
            echo json_encode(["status" => "gagal"]);
        }
        break;

    case "hapus":
        $nim = $_POST["nim"];
        $sql = "DELETE FROM alumni WHERE nim='$nim'";
        $result = mysqli_query($koneksi, $sql);

        if ($result && file_exists("foto/$nim.jpeg")) {
            unlink("foto/$nim.jpeg");
            echo json_encode(["status" => "berhasil"]);
        } else {
            echo json_encode(["status" => "gagal"]);
        }
        break;

    default:
        echo json_encode(["error" => "aksi tidak valid"]);
}
